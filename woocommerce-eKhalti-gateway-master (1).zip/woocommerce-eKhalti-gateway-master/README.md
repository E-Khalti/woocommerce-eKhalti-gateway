# Woocommerce-eKhalti-payment-gateway

For Woocommerce, the idea is users and developers should:
1. Download WooCommerce plugin
2. Install the plugin on your WooCommerce store
3. Enter your e-Khalti merchant id on your WooCommerce plugin settings


You can also download the zip file of the plugin from here:
https://www.unelmacloud.com/drive/s/DqfE6YBcSMLhbpADJB5SEpyLDeBug0
